import React from "react";
import { Text,View,StyleSheet } from "react-native";

