export default {
    primaryColor : "#4a14Bc",
    accentColor : "#fff00",
    blackColor : "#212121"
}