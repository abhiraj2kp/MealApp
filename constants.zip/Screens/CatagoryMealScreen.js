import React from "react";
import { View,Text,Button,StyleSheet } from "react-native";

const CatogoryMealScreen = props => {
    const catagoryItem = props.navigation.getParam("CatagoryId");
    
    return(
        <View style = {styles.container} >
            <Text>The CatogoryMealScreen {catagoryItem.title}</Text>
            <Button title = "Move to Meal details" onPress = {() => {
                props.navigation.navigate("MealDetails")
                }} />
        </View>
    )
} 

CatogoryMealScreen.navigationOptions = naviOpt => {
    console.log(naviOpt);
    const item = naviOpt.navigation.getParam("CatagoryId");
    return({
        headerTitle : item.title,
    }
    );
};

export default CatogoryMealScreen;

const styles = StyleSheet.create({
    container : {
        flex : 1,
        justifyContent : "center",
        alignItems : "center"
    }
});