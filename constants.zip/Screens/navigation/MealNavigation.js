import { createAppContainer } from "react-navigation";
import { createStackNavigator } from "react-navigation-stack";
import { Platform } from "react-native";
import Colors from '../constants/Colors';
import CatagoryMealScreen from "../Screens/CatagoryMealScreen";
import CatoagoryScreen from "../Screens/CatoagoryScreen";
import MealDetailsScreen from "../Screens/MealDetailsScreen";

const MealNavigator = createStackNavigator({
    Categories: CatoagoryScreen,
    CatagoryMeal: {
        screen: CatagoryMealScreen
    },
    MealDetails: MealDetailsScreen
    }, 
    {
        mode : "card",
        //initialRouteName : "MealDetails",
    defaultNavigationOptions: {
        headerStyle: {
            backgroundColor: Platform.OS === 'android' ? Colors.primaryColor : "",
        },
        headerTintColor: Platform.OS === 'android' ? "white" : Colors.primaryColor
    }
});

export default createAppContainer(MealNavigator);
