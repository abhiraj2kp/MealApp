import React from "react";
import { View,Text,StyleSheet,Button } from "react-native";

const MealDetailScreen = props => {
    return(
        <View style = {styles.container} >
            <Text>The MealDetailScreen</Text>
            <Button title = "Go Back" onPress = {() => {
                //props.navigation.goBack() // can be used in other navigator
                //props.navigation.pop() // only used in stacknavigator
                props.navigation.popToTop() //move to initial screen
            }} />
        </View>
    )
} 

export default MealDetailScreen;

const styles = StyleSheet.create({
    container : {
        flex : 1,
        justifyContent : "center",
        alignItems : "center"
    }
});